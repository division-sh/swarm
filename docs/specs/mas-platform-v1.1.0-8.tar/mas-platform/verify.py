#!/usr/bin/env python3
"""
MAS Platform Specification Verifier
Checks cross-reference integrity, event chains, payload coverage,
subscription resolution, and contract coherence.
"""
import yaml, os, sys, json
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
EC = os.path.join(BASE, 'empire', 'contracts')

errors = []
warnings = []

def error(category, msg):
    errors.append(f"[ERROR] {category}: {msg}")

def warn(category, msg):
    warnings.append(f"[WARN]  {category}: {msg}")

def load(path):
    with open(path) as f:
        return yaml.safe_load(f) or {}

# ============================================================
# 1. Load everything
# ============================================================
root_agents = load(f'{EC}/agents.yaml')
root_nodes = load(f'{EC}/nodes.yaml')
root_events = load(f'{EC}/events.yaml')
root_tools = load(f'{EC}/tools.yaml')
root_policy = load(f'{EC}/policy.yaml')
root_package = load(f'{EC}/package.yaml')

FLOWS = ['discovery', 'scoring', 'validation', 'operating']
flow_data = {}
for flow in FLOWS:
    fd = f'{EC}/flows/{flow}'
    flow_data[flow] = {
        'agents': load(f'{fd}/agents.yaml'),
        'nodes': load(f'{fd}/nodes.yaml'),
        'events': load(f'{fd}/events.yaml'),
        'schema': load(f'{fd}/schema.yaml'),
        'package': load(f'{fd}/package.yaml'),
    }
    tp = f'{fd}/tools.yaml'
    flow_data[flow]['tools'] = load(tp) if os.path.exists(tp) else {}
    pp = f'{fd}/policy.yaml'
    flow_data[flow]['policy'] = load(pp) if os.path.exists(pp) else {}

# Merge all
all_agents = dict(root_agents)
all_nodes = dict(root_nodes)
all_events = dict(root_events)
all_tools = dict(root_tools)
all_policy = dict(root_policy)

for flow in FLOWS:
    all_agents.update(flow_data[flow]['agents'])
    all_nodes.update(flow_data[flow]['nodes'])
    all_events.update(flow_data[flow]['events'])
    all_tools.update(flow_data[flow]['tools'])
    all_policy.update(flow_data[flow]['policy'])

# ============================================================
# 2. Event chain integrity
# ============================================================
events_emitted = set()
events_subscribed = set()
events_defined = set(k for k, v in all_events.items() if isinstance(v, dict))

# Collect emitters
for nid, node in all_nodes.items():
    if not isinstance(node, dict): continue
    for ev in node.get('produces', []):
        events_emitted.add(ev)
    for ev, h in node.get('event_handlers', {}).items():
        if not isinstance(h, dict): continue
        emits = h.get('emits')
        if isinstance(emits, str):
            events_emitted.add(emits)
        elif isinstance(emits, list):
            events_emitted.update(emits)
        # rules can emit
        rules = h.get('rules', {})
        if isinstance(rules, dict):
            for rn, r in rules.items():
                if isinstance(r, dict):
                    re = r.get('emits')
                    if isinstance(re, str): events_emitted.add(re)
                    elif isinstance(re, list): events_emitted.update(re)

for aid, agent in all_agents.items():
    if not isinstance(agent, dict): continue
    for ev in agent.get('emit_events', []):
        events_emitted.add(ev)

# Collect subscribers
for nid, node in all_nodes.items():
    if not isinstance(node, dict): continue
    for ev in node.get('subscribes_to', []):
        events_subscribed.add(ev.replace('*/', '').replace('/*', ''))
    for ev in node.get('event_handlers', {}).keys():
        events_subscribed.add(ev)

for aid, agent in all_agents.items():
    if not isinstance(agent, dict): continue
    for ev in agent.get('subscriptions', []) + agent.get('subscribes_to', []):
        ev_clean = str(ev).split('/')[-1] if '/' in str(ev) else str(ev)
        events_subscribed.add(ev_clean)

# Check: emitted but no definition
for ev in events_emitted:
    if ev not in events_defined and not ev.startswith('timer.') and not ev.startswith('*.'):
        warn("EVENT-NO-SCHEMA", f"'{ev}' emitted but no schema in events.yaml")

# Check: emitted but no subscriber
for ev in events_emitted:
    if ev not in events_subscribed and not ev.startswith('pipeline.') and ev in events_defined:
        warn("EVENT-NO-CONSUMER", f"'{ev}' emitted but nobody subscribes")

# Check: subscribed but nobody emits
for ev in events_subscribed:
    if ev not in events_emitted and ev in events_defined and not ev.startswith('timer.'):
        warn("EVENT-NO-PRODUCER", f"'{ev}' subscribed but nobody emits")

# ============================================================
# 3. Payload field coverage
# ============================================================
for flow in ['root'] + FLOWS:
    nodes = root_nodes if flow == 'root' else flow_data[flow]['nodes']
    for nid, node in nodes.items():
        if not isinstance(node, dict): continue
        for ev, h in node.get('event_handlers', {}).items():
            if not isinstance(h, dict): continue
            da = h.get('data_accumulation')
            if not isinstance(da, dict): continue
            source_ev = da.get('source_event', ev)
            event_schema = all_events.get(source_ev, {})
            payload_fields = set()
            if isinstance(event_schema, dict) and isinstance(event_schema.get('payload'), dict):
                payload_fields = set(event_schema['payload'].keys())
            writes = da.get('writes', [])
            for w in writes:
                if isinstance(w, str):
                    if payload_fields and w not in payload_fields:
                        error("PAYLOAD-MISMATCH", f"{flow}/{nid}/{ev}: writes '{w}' but {source_ev} payload has {payload_fields}")
                elif isinstance(w, dict):
                    sf = w.get('source_field', '')
                    if sf and payload_fields and sf not in payload_fields:
                        error("PAYLOAD-MISMATCH", f"{flow}/{nid}/{ev}: source_field '{sf}' not in {source_ev} payload")

# ============================================================
# 4. required_agents vs agents.yaml
# ============================================================
for flow in FLOWS:
    schema = flow_data[flow]['schema']
    agents = flow_data[flow]['agents']
    for ra in schema.get('required_agents', []):
        role = ra.get('role', '')
        agent = agents.get(role)
        if not isinstance(agent, dict):
            error("REQUIRED-AGENT-MISSING", f"{flow}: required role '{role}' not in agents.yaml")
            continue
        # Check emits
        schema_emits = set(ra.get('emits', []))
        agent_emits = set(agent.get('emit_events', []))
        diff = schema_emits - agent_emits
        if diff:
            error("EMIT-MISMATCH", f"{flow}/{role}: schema says emits {diff} but agent doesn't")

# ============================================================
# 5. Agent subscriptions resolve
# ============================================================
for flow in ['root'] + FLOWS:
    agents = root_agents if flow == 'root' else flow_data[flow]['agents']
    local_events = set()
    if flow != 'root':
        for k in flow_data[flow]['events']:
            if isinstance(flow_data[flow]['events'][k], dict):
                local_events.add(k)
    root_event_names = set(k for k, v in root_events.items() if isinstance(v, dict))
    
    for aid, agent in agents.items():
        if not isinstance(agent, dict): continue
        for sub in agent.get('subscriptions', []) + agent.get('subscribes_to', []):
            sub = str(sub)
            if '*' in sub: continue
            if '/' in sub: continue  # cross-flow, harder to verify
            if sub not in local_events and sub not in root_event_names and sub not in events_defined:
                warn("SUB-UNRESOLVED", f"{flow}/{aid}: subscribes to '{sub}' — not in any events.yaml")

# ============================================================
# 6. Handler field compliance
# ============================================================
DEFINED_HANDLER_FIELDS = {
    'description', '_note', 'guard', 'accumulate', 'compute', 'on_complete',
    'advances_to', 'sets_gate', 'data_accumulation', 'emits', 'rules',
    'fan_out', 'query', 'reduce', 'filter', 'count', 'clear', 'action',
    'template', 'instance_id_from', 'config_from', 'from', 'payload_transform',
    'clear_gates',
}

for flow in ['root'] + FLOWS:
    nodes = root_nodes if flow == 'root' else flow_data[flow]['nodes']
    for nid, node in nodes.items():
        if not isinstance(node, dict): continue
        for ev, h in node.get('event_handlers', {}).items():
            if not isinstance(h, dict): continue
            for field in h.keys():
                if field not in DEFINED_HANDLER_FIELDS:
                    error("UNDEFINED-FIELD", f"{flow}/{nid}/{ev}: handler field '{field}' not in platform spec")

# ============================================================
# 7. Tool references resolve
# ============================================================
for flow in ['root'] + FLOWS:
    agents = root_agents if flow == 'root' else flow_data[flow]['agents']
    for aid, agent in agents.items():
        if not isinstance(agent, dict): continue
        for tool in agent.get('tools_tier2', []):
            if tool not in all_tools and tool not in ['query_entities']:
                warn("TOOL-MISSING", f"{flow}/{aid}: references tool '{tool}' — not in any tools.yaml")

# ============================================================
# 8. Prompt files exist for all agents
# ============================================================
for flow in ['root'] + FLOWS:
    agents = root_agents if flow == 'root' else flow_data[flow]['agents']
    if flow == 'root':
        prompt_dir = f'{EC}/prompts'
    else:
        prompt_dir = f'{EC}/flows/{flow}/prompts'
    for aid in agents:
        if not isinstance(agents[aid], dict): continue
        prompt_path = f'{prompt_dir}/{aid}.md'
        if not os.path.exists(prompt_path):
            warn("PROMPT-MISSING", f"{flow}/{aid}: no prompt file at {prompt_path}")
        else:
            with open(prompt_path) as f:
                content = f.read()
            if '<!-- TODO' in content and '<!-- DEFERRED' not in content:
                warn("PROMPT-STUB", f"{flow}/{aid}: prompt contains TODO placeholder")

# ============================================================
# 9. Event naming consistency (deploy.completed vs devops.deploy_complete)
# ============================================================
for aid, agent in all_agents.items():
    if not isinstance(agent, dict): continue
    subs = agent.get('subscriptions', []) + agent.get('subscribes_to', [])
    emits = agent.get('emit_events', [])
    for ev in subs + emits:
        ev = str(ev).split('/')[-1] if '/' in str(ev) else str(ev)
        if ev not in events_defined and not ev.startswith('timer.') and '*' not in str(ev):
            warn("EVENT-UNDEFINED", f"{aid}: references '{ev}' — not defined in any events.yaml")

# ============================================================
# 10. Policy value conflicts
# ============================================================
for flow in FLOWS:
    fp = flow_data[flow]['policy']
    for key, fval in fp.items():
        if key in root_policy and key not in ['_note', 'description']:
            rval = root_policy[key]
            if fval != rval and not isinstance(fval, dict) and not isinstance(rval, dict):
                warn("POLICY-CONFLICT", f"'{key}': root={rval}, {flow}={fval}")

# ============================================================
# 11. deprecated fields still present
# ============================================================
DEPRECATED = ['subscriptions_bootstrap', 'logic', 'on_below_threshold', 'on_dedup', 'on_pass', 'policy_ref']
for flow in ['root'] + FLOWS:
    agents = root_agents if flow == 'root' else flow_data[flow]['agents']
    for aid, agent in agents.items():
        if isinstance(agent, dict):
            for dep in DEPRECATED:
                if dep in agent:
                    error("DEPRECATED", f"{flow}/{aid}: uses deprecated field '{dep}'")
    nodes = root_nodes if flow == 'root' else flow_data[flow]['nodes']
    for nid, node in nodes.items():
        if isinstance(node, dict):
            for ev, h in node.get('event_handlers', {}).items():
                if isinstance(h, dict):
                    for dep in DEPRECATED:
                        if dep in h:
                            error("DEPRECATED", f"{flow}/{nid}/{ev}: uses deprecated field '{dep}'")

# ============================================================
# Report
# ============================================================
print("=" * 70)
print("MAS PLATFORM VERIFICATION REPORT")
print("=" * 70)

print(f"\nERRORS: {len(errors)}")
for e in sorted(errors):
    print(f"  {e}")

print(f"\nWARNINGS: {len(warnings)}")
for w in sorted(warnings):
    print(f"  {w}")

print(f"\n{'=' * 70}")
print(f"SUMMARY: {len(errors)} errors, {len(warnings)} warnings")

# Counts
h = sum(len(n.get('event_handlers', {})) for n in all_nodes.values() if isinstance(n, dict))
a = sum(1 for v in all_agents.values() if isinstance(v, dict))
e = sum(1 for v in all_events.values() if isinstance(v, dict))
t = sum(1 for v in all_tools.values() if isinstance(v, dict))
print(f"COUNTS: {h} handlers, {a} agents, {e} events, {t} tools")
print("=" * 70)

sys.exit(1 if errors else 0)

# Count deferred prompts (informational only)
deferred = 0
for root, dirs, files in os.walk(os.path.join(BASE, 'empire', 'contracts')):
    for f in files:
        if f.endswith('.md') and 'prompts' in root:
            with open(os.path.join(root, f)) as fh:
                if '<!-- DEFERRED' in fh.read():
                    deferred += 1
if deferred:
    print(f"\n[INFO]  {deferred} prompts marked DEFERRED (intentional — will be completed before first OpCo spinup)")
